<?php
session_start();
$error_message = false;
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : '';

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    // Include database connection
    require_once 'db_connect.php';
    
    // Get form data
    $username = $_POST['username'];
    $password = $_POST['pass'];

    // Check in users table (new approach)
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows == 1){
        $user = $result->fetch_assoc();
        
        // Verify password
        if(password_verify($password, $user['password'])){
            // Set session variables
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Redirect based on role
            if($user['role'] === 'admin'){
                header("location: " . ($redirect ? $redirect : "admin.php"));
            } else {
                header("location: " . ($redirect ? $redirect : "dashboard.php"));
            }
            exit;
        } else {
            $error_message = "Invalid password";
        }
    } else {
        // Legacy check in registration table for backward compatibility
        $stmt = $conn->prepare("SELECT * FROM registration WHERE Username = ? AND Password = ?");
        $stmt->bind_param("ss", $username, $password); // Note: this is not secure, but maintaining for compatibility
        $stmt->execute();
        $result = $stmt->get_result();
        
        if($result->num_rows == 1){
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;
            header("location: " . ($redirect ? $redirect : "index.php"));
            exit;
        } else {
            $error_message = "Invalid username or password";
        }
    }
    
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Ice Cream Wonderland</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
  body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  padding: 0;
  height: 100vh;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #333;
  background: url('images/icecream1.jpg') no-repeat center center fixed;
  background-size: cover;
  animation: wallpaper-zoom 10s infinite alternate;
}

.auth-options {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 10px;
    margin-bottom: 15px;
}

.forgot-password,
.signup-button {
    text-decoration: none;
    font-size: 14px;
    color: #d32f2f;
    margin: 0 10px;
    transition: color 0.3s;
}

.forgot-password:hover,
.signup-button:hover {
    color: #ff6b6b;
    text-decoration: underline;
}


@keyframes wallpaper-zoom {
  0% {
    transform: scale(1);
  }
  100% {
    transform: scale(1.1);
  }
}

.logincart {
  background: rgba(255, 255, 255, 0.9);
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  text-align: center;
  max-width: 400px;
  width: 100%;
  backdrop-filter: blur(10px);
}

    h1 {
        margin-bottom: 1.5rem;
        color: #d32f2f;
      }

      input[type="text"],
      input[type="password"] {
        width: 100%;
        padding: 0.8rem;
        margin: 0.5rem 0;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 1rem;
      }

      button {
        width: 100%;
        padding: 0.8rem;
        border: none;
        border-radius: 5px;
        font-size: 1rem;
        cursor: pointer;
        margin-top: 1rem;
        transition: background-color 0.3s ease;
      }

      button[type="submit"] {
        background-color: #d32f2f;
        color: white;
      }

      button[type="submit"]:hover {
        background-color: #b71c1c;
      }

      button i {
        vertical-align: middle;
        margin-right: 0.5rem;
      }

      button a {
        text-decoration: none;
        color: inherit;
      }

      h4 {
        margin: 0.5rem 0;
        font-weight: 400;
      }

      h4 a {
        color: #d32f2f;
        text-decoration: none;
        font-weight: 600;
      }

      h4 a:hover {
        text-decoration: underline;
      }

      h3 {
        margin: 1rem 0;
        font-weight: 400;
        color: #555;
      }

      .social-buttons {
        display: flex;
        gap: 1rem;
        justify-content: center;
      }

      .social-buttons button {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        font-size: 0.9rem;
        padding: 0.8rem;
      }

      .social-buttons button.google {
        background-color: #dee2e6;
        color: black;
      }

      .social-buttons button.facebook {
        background-color: #4267B2;
        color: white;
      }

      .error-message {
        padding: 10px;
        background-color: rgb(248, 212, 212);
        color: rgb(198, 26, 26);
        border: 1px solid #ffcdd2;
        border-radius: 4px;
        margin-bottom: 1rem;
      }

      .home-link {
        position: absolute;
        top: 20px;
        left: 20px;
        color: white;
        text-decoration: none;
        font-size: 1rem;
        display: flex;
        align-items: center;
        background: rgba(211, 47, 47, 0.8);
        padding: 8px 15px;
        border-radius: 5px;
        transition: background 0.3s;
      }

      .home-link:hover {
        background: rgba(211, 47, 47, 1);
      }

      .home-link i {
        margin-right: 5px;
      }

      @media (max-width: 600px) {
        .logincart {
          padding: 1.5rem;
        }

        button {
          font-size: 0.9rem;
        }

        input {
          font-size: 0.9rem;
        }
      }
    </style>
  </head>
  <body>
    <a href="index.php" class="home-link"><i class="fas fa-home"></i> Back to Home</a>

    <div class="logincart">
      <h1>Login</h1>
      
      <?php if($error_message): ?>
        <div class="error-message"><?php echo $error_message; ?></div>
      <?php endif; ?>
      
      <?php if(isset($_GET['error']) && $_GET['error'] === 'admin_required'): ?>
        <div class="error-message">You need to login as an admin to access that page.</div>
      <?php endif; ?>
      
      <form method="POST">
        <input type="text" placeholder="Enter your Username" name="username" required>
        <input type="password" placeholder="Enter your Password" name="pass" required>
        
        <div class="auth-options">
          <a href="forgot_password.php" class="forgot-password">Forgot Password?</a>
          <a href="signup.php" class="signup-button">Sign Up</a>
        </div>

        <button type="submit"><i class="fas fa-sign-in-alt"></i> Log in</button>
      </form>
      
      <h3>or</h3>
      
      <div class="social-buttons">
        <button class="google">
          <i class="fab fa-google"></i> Continue with Google
        </button>
        <button class="facebook">
          <i class="fab fa-facebook-f"></i> Continue with Facebook
        </button>
      </div>
    </div>
  </body>
</html>
